Auth App
-----------------------------------------------------------------------------

Backend:
________

MongoDb:
--------

![Screenshot 2024-02-01 205632](https://github.com/sanjeeb09/mern-auth/assets/50053860/38614f96-7184-4a7b-ad82-ef047aa3bee3)

![Screenshot 2024-02-01 205706](https://github.com/sanjeeb09/mern-auth/assets/50053860/8a1779d7-44a4-457f-a972-89eed500f811)


Insomnia:
---------

![Screenshot 2024-02-01 143308](https://github.com/sanjeeb09/mern-auth/assets/50053860/8f487f7d-86f5-4678-9a44-c8ac5776e202)

![Screenshot 2024-02-01 143404](https://github.com/sanjeeb09/mern-auth/assets/50053860/f593c994-4ee0-47bd-89ba-5b7a431e23e7)

![Screenshot 2024-02-01 143546](https://github.com/sanjeeb09/mern-auth/assets/50053860/706ad1aa-813f-4484-bd1f-05cdc5c7ccdb)


Google Firebase For Google OAuth:
---------------------------------

![Screenshot 2024-02-01 210630](https://github.com/sanjeeb09/mern-auth/assets/50053860/ae59ae93-1ded-4f2d-b1bf-160b43c6f516)


Frontend and Website:
______________________

![Screenshot 2024-02-01 203711](https://github.com/sanjeeb09/mern-auth/assets/50053860/aac82331-fa44-4644-9e35-7b2f93441418)

![Screenshot 2024-02-01 203802](https://github.com/sanjeeb09/mern-auth/assets/50053860/7deeebc0-108a-49f8-93e1-5dc170e34750)

![Screenshot 2024-02-01 203939](https://github.com/sanjeeb09/mern-auth/assets/50053860/0769a515-d39c-4198-8ee3-39060d98200e)

![Screenshot 2024-02-01 204208](https://github.com/sanjeeb09/mern-auth/assets/50053860/e02ec95d-c778-4200-a24f-5c6d78594eac)

![Screenshot 2024-02-01 204304](https://github.com/sanjeeb09/mern-auth/assets/50053860/a30bc028-b5e8-47e8-8639-031916676c85)

![Screenshot 2024-02-01 204320](https://github.com/sanjeeb09/mern-auth/assets/50053860/ec260803-8db0-4baf-8d18-ae8b5976dabf)

![Screenshot 2024-02-01 204341](https://github.com/sanjeeb09/mern-auth/assets/50053860/ce7d7050-c3e5-43bf-9460-383524b3866f)

![Screenshot 2024-02-01 204405](https://github.com/sanjeeb09/mern-auth/assets/50053860/48a5f5c6-b2fc-4b9e-b257-78a341c835c0)

![Screenshot 2024-02-01 205300](https://github.com/sanjeeb09/mern-auth/assets/50053860/f1b2d637-fa2e-4dfe-b86e-830937c8d567)

